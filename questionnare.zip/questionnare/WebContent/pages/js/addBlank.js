var x;
function init()
{
	if(window.XMLHttpRequest)
    {
	    x=new XMLHttpRequest();
	}
	else
    {
		x=new ActiveXObject("Microsoft.XMLHTTP");
    } 		
}
function get()
{
	if($.cookie('getflag')!="full")
	{
		return;
	}
	init();
    x.open("GET","../ServiceGetResult",true);
    x.onreadystatechange=result;
    x.send(); 		  	  
}
function result()
{
	if(x.readyState==4 && x.status==200)
	{
		if(x.responseText=="error")
		{
			$.cookie('getflag', null);
			alert("创建失败,请检查数据库连接！");
		}
		else if(x.responseText=="repeat")
		{
			$.cookie('getflag', null);
			alert("该题目已存在,请重新添加！");
		}		
	}
}