var x,y,z;
function init()
{
	if(window.XMLHttpRequest)
    {
	    x=new XMLHttpRequest();
	    y=new XMLHttpRequest();
	    z=new XMLHttpRequest();
	}
	else
    {
		x=new ActiveXObject("Microsoft.XMLHTTP");
		y=new ActiveXObject("Microsoft.XMLHTTP");
		z=new ActiveXObject("Microsoft.XMLHTTP");
    } 		
}
function editCheck(paperID)
{
    x.open("GET","../Service?paperID="+paperID,true);
    x.onreadystatechange=editCheckResult;
    x.send(); 		  	  
}
function editCheckResult()
{
	if(x.readyState==4 && x.status==200)
	{		
		if(x.responseText=="same")
		{
			alert("请先取消该问卷的发布状态!");
		}
		else
		{
		    window.location="../CreateTitle?paperID=" + x.responseText;
		}
	}
}
function publish(paperID)
{
		y.open("GET","../ServiceGetQuestionCount?paperID="+paperID,true);
	    y.onreadystatechange=publishResult;
	    y.send();	  	  
}
function publishResult()
{
	if(y.readyState==4 && y.status==200)
	{		
		if(y.responseText=="0")
		{
			alert("该问卷未添加任何题目!");
		}
		else
		{
			if(confirm("确定发布该问卷?")){
				window.location="../Publish?paperID=" + y.responseText;				
			} 			
		}
	}
}
function down()
{
	if(confirm("确定取消该问卷发布状态?")){
		window.location="../Down";
	} 		  	  
}
function statisticsCheck(paperID)
{
    x.open("GET","../ServiceStatistics?paperID="+paperID,true);
    x.onreadystatechange=statisticsCheckResult;
    x.send(); 		  	  
}
function statisticsCheckResult()
{
	if(x.readyState==4 && x.status==200)
	{		
		if(x.responseText=="0")
		{
			alert("该问卷当前未收集到任何结果!");
		}
		else
		{
			window.location="../GetStatistics?paperID=" + x.responseText;
		}
	}
}
function deleteCheck(paperID)
{
    x.open("GET","../Service?paperID="+paperID,true);
    x.onreadystatechange=deleteCheckResult;
    x.send(); 		  	  
}
function deleteCheckResult()
{
	if(x.readyState==4 && x.status==200)
	{		
		if(x.responseText=="same")
		{
			alert("请先取消该问卷的发布状态!");
		}
		else
		{
			if(confirm("确认删除该问卷?")){
				window.location="../Delete?paperID=" + x.responseText;
			}
		}
	}
}