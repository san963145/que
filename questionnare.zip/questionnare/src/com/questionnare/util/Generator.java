package com.questionnare.util;

import java.util.ArrayList;

import com.questionnare.model.Paper;
import com.questionnare.model.Question;

public class Generator {
	
	public static String generatePaperList(String curPaperID,ArrayList<Paper> paperList)
	{		
		StringBuilder s=new StringBuilder();
		s.append("<ul id=\"ulQs\" class=\"survey_list\">");
		int size=paperList.size();
		for(int i=0;i<size;i++){
			Paper paper=paperList.get(i);
			s.append("<li class=\"list_li\" aid=\"");
			s.append(paper.getPaperID());
			s.append("\">");
			s.append("<div class=\"list_li_conent\">");
			s.append("<div class=\"list_text\">");
			s.append(paper.getTitle());
			if(curPaperID.equals(paper.getPaperID())){
				s.append("<b style=\"color:#d43f3a\">&nbsp;&nbsp;发布中&nbsp;&nbsp;</b>");
				//s.append("<a style=\"font-size:18px;float:right;\" href=\"../GetPaper?isPreview=1&paperID="+paper.getPaperID()+"\"><b>预览</b></a>");
			}			
			s.append("</div><div class=\"list_r\"><span class=\"wjNumber\">");
			s.append(paper.getQuestionCount());
			s.append("</span>");
			if(curPaperID.equals(paper.getPaperID())){
				s.append("</div></div><div style=\"display: none;\" class=\"share_result_menu\" ><ul><li><a href=\"javascript:;\" class=\"sr_list_preview\"><div class=\"icon\"><i class=\"glyphicon glyphicon-search\"></i><p class=\"glyphicon_font\">&nbsp;预览</p></div></a></li><li><a href=\"javascript:;\" class=\"sr_down\" needpub=\"1\"><div class=\"icon\"><i class=\"glyphicon glyphicon-download-alt\"></i><p class=\"glyphicon_font\">&nbsp;回收</p></div></a></li><li><a href=\"javascript:;\" class=\"sr_result\"><div class=\"icon\"><i class=\"glyphicon glyphicon-signal\"></i><p class=\"glyphicon_font\"> &nbsp;&nbsp;统计</p></div></a></li><li><a href=\"javascript:;\" class=\"sr_list_del\"><div class=\"icon\"><i class=\"glyphicon glyphicon-trash\"></i><p class=\"glyphicon_font\"> &nbsp;删除</p></div></a></li></ul></div></li>");
			}
			else{
				s.append("</div></div><div style=\"display: none;\" class=\"share_result_menu\" ><ul><li><a href=\"javascript:;\" class=\"sr_list_edit\"><div class=\"icon\"><i class=\"glyphicon glyphicon-pencil\"></i><p class=\"glyphicon_font\">编辑</p></div></a></li><li><a href=\"javascript:;\" class=\"sr_share\" needpub=\"1\"><div class=\"icon\"><i class=\"glyphicon glyphicon-new-window\"></i><p class=\"glyphicon_font\">&nbsp;发布</p></div></a></li><li><a href=\"javascript:;\" class=\"sr_result\"><div class=\"icon\"><i class=\"glyphicon glyphicon-signal\"></i><p class=\"glyphicon_font\"> &nbsp;&nbsp;统计</p></div></a></li><li><a href=\"javascript:;\" class=\"sr_list_del\"><div class=\"icon\"><i class=\"glyphicon glyphicon-trash\"></i><p class=\"glyphicon_font\"> &nbsp;删除</p></div></a></li></ul></div></li>");
			}
		}					
        s.append("</ul>");
		return s.toString();
	}
	public static String generateQuestionList(ArrayList<Question> questionList)
	{		
		StringBuilder s=new StringBuilder();		
		int size=questionList.size();
		for(int i=0;i<size;i++){
			Question question=questionList.get(i);
			String type="单选";
			if(question.getType().equals("2")){
				type="多选";
			}else if(question.getType().equals("3")){
				type="填空";
			}
			s.append("<li class=\"q_list_li\" topic=\"1\"><div class=\"q_list_text\">");
			s.append("<h2>"+question.getTitle()+"<span style=\"color: #adadad;\">("+type+")</span></h2>");
			s.append("<div class=\"q_linst_info\"><a style=\" font-size:16px; display:block;\" href=\"../DeleteQuestion?questionID="+question.getQuestionID()+"\">删除</a></div><div style=\"clear:both;\"></div></div></li>");			
		}					
		return s.toString();
	}
	public static String generateFullPaper(Paper paper,ArrayList<Question>questions)
	{		
		StringBuilder s=new StringBuilder();
		s.append("<fieldset class=\"fieldset\" id=\"fieldset1\">");
		int size=questions.size();
		int sequence=0;
		for(int i=0;i<size;i++){
			Question question=questions.get(i);
			if(!question.getType().trim().equals("3")){
				sequence++;
			}
			if(question.getType().trim().equals("1")){
				//s.append("<div class=\"singleQuestion\" id=\""+question.getQuestionID()+"\"></div>");
				s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\"><div class=\"field-label\">");
				s.append(sequence);
				s.append(".");
				s.append(question.getTitle());
				s.append("<span class=\"qtypetip\">&nbsp;[单选题]</span></div><div class=\"ui-controlgroup\">");
				if(question.getItemA().length()!=0){
					s.append("<div class=\"ui-radio\"><input type=\"radio\" value=\"A\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("A.");
					s.append(question.getItemA());
					s.append("</span></div>");
				}
				if(question.getItemB().length()!=0){
					s.append("<div class=\"ui-radio\"><input type=\"radio\" value=\"B\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("B.");
					s.append(question.getItemB());
					s.append("</span></div>");
				}
				if(question.getItemC().length()!=0){
					s.append("<div class=\"ui-radio\"><input type=\"radio\" value=\"C\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("C.");
					s.append(question.getItemC());
					s.append("</span></div>");
				}
				if(question.getItemD().length()!=0){
					s.append("<div class=\"ui-radio\"><input type=\"radio\" value=\"D\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("D.");
					s.append(question.getItemD());
					s.append("</span></div>");
				}
				if(question.getItemE().length()!=0){
					s.append("<div class=\"ui-radio\"><input type=\"radio\" value=\"E\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("E.");
					s.append(question.getItemE());
					s.append("</span></div>");
				}
				if(question.getItemF().length()!=0){
					s.append("<div class=\"ui-radio\"><input type=\"radio\" value=\"F\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("F.");
					s.append(question.getItemF());
					s.append("</span></div>");
				}			
				s.append("</div></div>");
			}else if(question.getType().trim().equals("2")){
				s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\"><div class=\"field-label\">");
				s.append(sequence);
				s.append(".");
				s.append(question.getTitle());
				s.append("<span class=\"qtypetip\">&nbsp;[多选题]</span></div><div class=\"ui-controlgroup\">");
				if(question.getItemA().length()!=0){
					s.append("<div class=\"ui-checkbox\"><input type=\"checkbox\" value=\"A\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("A.");
					s.append(question.getItemA());
					s.append("</span></div>");
				}
				if(question.getItemB().length()!=0){
					s.append("<div class=\"ui-checkbox\"><input type=\"checkbox\" value=\"B\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("B.");
					s.append(question.getItemB());
					s.append("</span></div>");
				}
				if(question.getItemC().length()!=0){
					s.append("<div class=\"ui-checkbox\"><input type=\"checkbox\" value=\"C\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("C.");
					s.append(question.getItemC());
					s.append("</span></div>");
				}
				if(question.getItemD().length()!=0){
					s.append("<div class=\"ui-checkbox\"><input type=\"checkbox\" value=\"D\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("D.");
					s.append(question.getItemD());
					s.append("</span></div>");
				}
				if(question.getItemE().length()!=0){
					s.append("<div class=\"ui-checkbox\"><input type=\"checkbox\" value=\"E\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("E.");
					s.append(question.getItemE());
					s.append("</span></div>");
				}
				if(question.getItemF().length()!=0){
					s.append("<div class=\"ui-checkbox\"><input type=\"checkbox\" value=\"F\" seq=\""+sequence+"\" name=\""+question.getQuestionID()+"\"><span class=\"choice_label\">");
					s.append("F.");
					s.append(question.getItemF());
					s.append("</span></div>");
				}			
				s.append("</div></div>");
			}			
		}		
		for(int i=0;i<questions.size();i++){
			Question question=questions.get(i);
			if(question.getType().trim().equals("3")){
				sequence++;
				s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\"><div class=\"field-label\">");
				s.append(sequence);
				s.append(".");
				s.append(question.getTitle());
				s.append("<span class=\"qtypetip\">&nbsp;[填空题]</span></div>");
				s.append("<input class=\"q_blank\" seq=\""+sequence+"\" name=\"");
				s.append(question.getQuestionID());
				s.append("\" size=\"16\" placeholder=\"作答区\" style=\"BACKGROUND-COLOR:transparent;height:20px;border:0px;border-bottom:#9a9898 1px solid;\"></input>");
				s.append("</div>");
			}
		}
        s.append("</fieldset>");
		return s.toString();
	}
	public static String generateQuestion(Question question,int sequence)
	{		
		StringBuilder s=new StringBuilder();
		String type="单选题";
		if(question.getType().trim().equals("2")){
			type="多选题";
		}else if(question.getType().trim().equals("3")){
			type="填空题";
		}
		s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\"><div class=\"field-label\">");
		s.append(sequence);
		s.append(".");
		s.append(question.getTitle());
		s.append("<span class=\"qtypetip\">&nbsp;["+type+"]</span></div>");		
		if(question.getType().trim().equals("3")){
			return s.toString();
		}
		s.append("<div class=\"ui-controlgroup\">");
		if(question.getItemA().length()!=0){
			s.append("<div class=\"ui-radio\"><span class=\"choice_label\" style=\"margin-left: 13px;\">");
			s.append("A.");
			s.append(question.getItemA());
			s.append("</span></div>");
		}
		if(question.getItemB().length()!=0){
			s.append("<div class=\"ui-radio\"><span class=\"choice_label\" style=\"margin-left: 13px;\">");
			s.append("B.");
			s.append(question.getItemB());
			s.append("</span></div>");
		}
		if(question.getItemC().length()!=0){
			s.append("<div class=\"ui-radio\"><span class=\"choice_label\" style=\"margin-left: 13px;\">");
			s.append("C.");
			s.append(question.getItemC());
			s.append("</span></div>");
		}
		if(question.getItemD().length()!=0){
			s.append("<div class=\"ui-radio\"><span class=\"choice_label\" style=\"margin-left: 13px;\">");
			s.append("D.");
			s.append(question.getItemD());
			s.append("</span></div>");
		}
		if(question.getItemE().length()!=0){
			s.append("<div class=\"ui-radio\"><span class=\"choice_label\" style=\"margin-left: 13px;\">");
			s.append("E.");
			s.append(question.getItemE());
			s.append("</span></div>");
		}
		if(question.getItemF().length()!=0){
			s.append("<div class=\"ui-radio\"><span class=\"choice_label\" style=\"margin-left: 13px;\">");
			s.append("F.");
			s.append(question.getItemF());
			s.append("</span></div>");
		}			
		s.append("</div></div>");
		return s.toString();
	}
	public static String generateTable(int columnNum,String[] head,ArrayList<ArrayList<String>> content,String type)
	{		
		StringBuilder s=new StringBuilder();
		if(!type.equals("3")){
			s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\">");			
		}
		s.append("<table class=\"table table-bordered q_blank\">");
		s.append("<thead><tr>");
        for(int i=0;i<columnNum;i++)
        {
        	s.append("<th>"+head[i]+"</th>");
        }
        s.append("</thead>");
        s.append("<tbody>");
        int rowNum=content.size();
        for(int i=0;i<rowNum;i++)
        {
        	s.append("<tr>");
        	ArrayList<String>row=content.get(i);
        	
        	int cNum=row.size();
        	for(int j=0;j<cNum;j++)
        	{
        	  s.append("<td>"+row.get(j)+"</td>");
        	}
        	s.append("</tr>");
        }
        s.append("</tbody>");
        s.append("</table>");
        if(!type.equals("3")){
        	s.append("</div>");
        }
		return s.toString();
	}
	public static String generateFullStatistics(ArrayList<ArrayList<String>> content)
	{		
		StringBuilder s=new StringBuilder();
		s.append("<fieldset class=\"fieldset\" id=\"fieldset1\">");
		for(int i=0;i<content.size();i++){
			String questionID=content.get(i).get(0);
			String type=content.get(i).get(1);
			String questionContent=content.get(i).get(2);			
			String resultContent=content.get(i).get(3);			
			s.append(questionContent);
			s.append(resultContent);
			if(!type.equals("3")){
				String pieDivContent=ChartGenerator.generatePieDiv(questionID);
				String barDivContent=ChartGenerator.generateBarDiv(questionID);
				s.append(pieDivContent);
				s.append(barDivContent);
			}
		}
		s.append("</fieldset>");
		return s.toString();
	}

}
