package com.questionnare.util;

import java.util.ArrayList;

public class ChartGenerator {
    
	public static String generatePieDiv(String questionID){
		StringBuilder s=new StringBuilder();
		s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\" style=\"height: 250px;margin-top:-20px;border:0px;\">");
		s.append("<div id=\"pie");
		s.append(questionID);
		s.append("\" style=\"height: 100%; width:90%;\"></div>");
		s.append("</div>");
		return s.toString();
	}
	public static String generateBarDiv(String questionID){
		StringBuilder s=new StringBuilder();
		s.append("<div class=\"field ui-field-contain\" id=\"div1\" req=\"1\" topic=\"1\" data-role=\"fieldcontain\" type=\"3\" style=\"height: 250px;margin-top:-70px;border:0px;\">");
		s.append("<div id=\"bar");
		s.append(questionID);
		s.append("\" style=\"height: 100%; width:90%;\"></div>");
		s.append("</div>");
		return s.toString();
	}
	public static String generateChart(String questionID,ArrayList<ArrayList<String>> list){
		StringBuilder s=new StringBuilder();
		s.append("<script type=\"text/javascript\">");
		s.append("var dom= document.getElementById(\"pie"+questionID+"\");");
		s.append("var myChart= echarts.init(dom);");
		s.append("var option = {series: [{type:'pie',radius: ['40%', '55%'],");
		s.append("data:[");
		for(int i=0;i<list.size();i++){
			String answer=list.get(i).get(0);
			String count=list.get(i).get(1);
			s.append("{value:"+count+", name:'"+answer+"'},");
		}
		s.append("]}]};");
		s.append("if (option && typeof option === \"object\") {myChart.setOption(option, true);}");
		s.append("</script>");
		
		s.append("<script type=\"text/javascript\">");
		s.append("var dom= document.getElementById(\"bar"+questionID+"\");");
		s.append("var myChart= echarts.init(dom);");
		s.append("var option = {color: ['#3398DB'],grid: {left: '3%',right: '4%',bottom: '3%',containLabel: true},");
		s.append("xAxis : [{type : 'category',");
		s.append("data:[");
		for(int i=0;i<list.size();i++){
			String answer=list.get(i).get(0);
			s.append("'"+answer+"',");
		}
		s.append("],splitLine:false,axisTick: {alignWithLabel: true}}],yAxis : [{type : 'value',splitLine:false,}],");
		s.append("series : [{type:'bar',");
		s.append("data:[");
		for(int i=0;i<list.size();i++){
			String count=list.get(i).get(1);
			s.append(count+",");
		}
		s.append("]}]};");
		s.append("if (option && typeof option === \"object\") {myChart.setOption(option, true);}");
		s.append("</script>");
		return s.toString();
	}
	
}
