package com.questionnare.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class Data {
	
	public static String result="";
	
	public static String URL="http://cheline.applinzi.com/";
	
	public static Map<String,String>map=new HashMap<String,String>();
	
	public String getAttribute(String name){
		Connection conn=ConnManager.getConnection(); 
		try
		{
			PreparedStatement ps = conn.prepareStatement("select * from cache where name=?");
			ps.setString(1, name);
			ps.execute();
			ResultSet rs=ps.getResultSet();			
			if(rs.next())
			{
				return rs.getString("value");
			}	
		}  catch(Exception e)
		  {
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return null;
	}
	
	public boolean removeAttribute(String name){
		Connection conn=ConnManager.getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			PreparedStatement ps = conn.prepareStatement("delete from cache where name=?");
			ps.setString(1, name);
			ps.execute();
			conn.commit();
		}  catch(Exception e)
		  {
			try {
				conn.rollback();
				return false;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return true;
	}
	
	public boolean clear(){
		Connection conn=ConnManager.getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			PreparedStatement ps = conn.prepareStatement("delete from cache");
			ps.execute();
			conn.commit();
		}  catch(Exception e)
		  {
			try {
				conn.rollback();
				return false;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return true;
	}
	public boolean setAttribute(String name,String value)
	{	
		Connection conn=ConnManager.getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try
		{
			PreparedStatement ps = conn.prepareStatement("insert into cache(name,value) values(?,?)");
			ps.setString(1, name);
			ps.setString(2, value);
			ps.execute();
			conn.commit();
			return true;
		}  catch(Exception e)
		  {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		  }		
		   finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  return false;
	}

}
