package com.questionnare.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.AdminDao;
import com.questionnare.dao.Data;

/**
 * Servlet implementation class Admin
 */
@WebServlet("/Admin")
public class Admin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Cookie[] cookies=request.getCookies();
		boolean flag=true;
		for(Cookie cookie:cookies){
			if(cookie.getName().equals("getflag")){
				cookie.setValue("full");
				response.addCookie(cookie);
				flag=false;
				break;
			}
		}
		if(flag){
			Cookie cookie=new Cookie("getflag","full");
			response.addCookie(cookie);
		}	
		String userID=request.getParameter("userID");
		String oldPassword=request.getParameter("oldPassword");
		String newPassword=request.getParameter("newPassword");
		String checkOld=AdminDao.checkAdminLogin(userID, oldPassword);
		if(checkOld==null){
			Data.result="wrong";
			request.getRequestDispatcher("pages/admin.jsp").forward(request, response);
			return;
		}
		boolean updateResult=AdminDao.update(userID, newPassword);
		if(!updateResult){
			Data.result="error";
			request.getRequestDispatcher("pages/admin.jsp").forward(request, response);
			return;
		}
		Data.result="success";
		request.getRequestDispatcher("pages/admin.jsp").forward(request, response);
		return;
	}

}
