package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.Data;
import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Paper;
import com.questionnare.model.Question;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class AddQuestion
 */
@WebServlet("/AddQuestion")
public class AddQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddQuestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Cookie[] cookies=request.getCookies();
		boolean flag=true;
		for(Cookie cookie:cookies){
			if(cookie.getName().equals("getflag")){
				cookie.setValue("full");
				response.addCookie(cookie);
				flag=false;
				break;
			}
		}
		if(flag){
			Cookie cookie=new Cookie("getflag","full");
			response.addCookie(cookie);
		}
		String title=request.getParameter("title");
		String typeChoice=request.getParameter("typeChoice");
		String itemCount=request.getParameter("itemCount");
		String itemA=request.getParameter("itemA");
		String itemB=request.getParameter("itemB");
		String itemC=request.getParameter("itemC");
		String itemD=request.getParameter("itemD");
		String itemE=request.getParameter("itemE");
		String itemF=request.getParameter("itemF");
		String paperID=request.getParameter("paperID");		
		Paper paper=PaperDao.getPaperByPaperID(paperID);
		if(typeChoice==null){
			typeChoice="1";
		}else if(typeChoice.length()==0){
			typeChoice="1";
		}	
		boolean isCompleted=isCompleted(request);
		if(!isCompleted){
			Data.result="notComplete";
			request.setAttribute("result","notComplete");
			request.getRequestDispatcher("pages/addQuestion.jsp?item="+itemCount).forward(request, response);
			return;
		}
		boolean isRepeated=QuestionDao.get(title, typeChoice,paperID);
		if(isRepeated){
			Data.result="repeat";
			//request.setAttribute("result","repeat");
			request.getRequestDispatcher("pages/addQuestion.jsp?item="+itemCount).forward(request, response);
			return;
		}
		boolean isItemRepeated=isItemRepeated(request);
		if(isItemRepeated){
			Data.result="itemRepeated";
			request.setAttribute("result","itemRepeated");
			request.getRequestDispatcher("pages/addQuestion.jsp?item="+itemCount).forward(request, response);
			return;
		}
		boolean addResult=QuestionDao.add(title, typeChoice, itemA, itemB, itemC, itemD, itemE, itemF, paperID);
	    if(addResult){
	    	Data.result="success";
	    	//request.setAttribute("result","success");
	    	ArrayList<Question> questions=QuestionDao.getQuestionsByPaperID(paperID);
	    	String questionList=Generator.generateQuestionList(questions);
	    	request.setAttribute("paperID",paperID);
			request.setAttribute("title",paper.getTitle());
			request.setAttribute("description",paper.getDescription());
			request.setAttribute("questionList",questionList);
			request.getRequestDispatcher("pages/editNew.jsp").forward(request, response);
			return;
	    }else{
	    	Data.result="error";
	    	//request.setAttribute("result","error");
	    	request.getRequestDispatcher("pages/addQuestion.jsp?item="+itemCount).forward(request, response);
			return;
	    }
	
	}
	private boolean isCompleted(HttpServletRequest request){
		String c=request.getParameter("itemCount");
		String itemA=request.getParameter("itemA");
		String itemB=request.getParameter("itemB");
		String itemC=request.getParameter("itemC");
		String itemD=request.getParameter("itemD");
		String itemE=request.getParameter("itemE");
		String itemF=request.getParameter("itemF");
		int itemCount=Integer.parseInt(c);
		boolean isCompleted=true;
		switch(itemCount){
		case(2):if(itemA==null||itemB==null){
			       isCompleted=false;
		        }else if(itemA.trim().length()==0 || itemB.trim().length()==0){
		           isCompleted=false;
		        }
		        break;
		case(3):if(itemA==null||itemB==null||itemC==null){
		           isCompleted=false;
	            }else if(itemA.trim().length()==0 || itemB.trim().length()==0 || itemC.trim().length()==0){
	               isCompleted=false;
	            }
	            break;
		case(4):if(itemA==null||itemB==null||itemC==null||itemD==null){
	           	   isCompleted=false;
                }else if(itemA.trim().length()==0 || itemB.trim().length()==0 || itemC.trim().length()==0|| itemD.trim().length()==0){
                   isCompleted=false;
                }
                break;
		case(5):if(itemA==null||itemB==null||itemC==null||itemD==null||itemE==null){
        	       isCompleted=false;
                }else if(itemA.trim().length()==0 || itemB.trim().length()==0 || itemC.trim().length()==0|| itemD.trim().length()==0|| itemE.trim().length()==0){
                   isCompleted=false;
                }
                break;
		case(6):if(itemA==null||itemB==null||itemC==null||itemD==null||itemE==null||itemF==null){
 	               isCompleted=false;
                }else if(itemA.trim().length()==0 || itemB.trim().length()==0 || itemC.trim().length()==0|| itemD.trim().length()==0|| itemE.trim().length()==0|| itemF.trim().length()==0){
                   isCompleted=false;
                }
                break;
		}
		return isCompleted;
	}
	private boolean isItemRepeated(HttpServletRequest request){
		String c=request.getParameter("itemCount");
		String itemA=request.getParameter("itemA");
		String itemB=request.getParameter("itemB");
		String itemC=request.getParameter("itemC");
		String itemD=request.getParameter("itemD");
		String itemE=request.getParameter("itemE");
		String itemF=request.getParameter("itemF");
		int itemCount=Integer.parseInt(c);
		boolean isRepeated=false;
		switch(itemCount){
		case(2):if(itemA.equals(itemB)){
			       isRepeated=true;
		        }
		        break;
		case(3):if(itemA.equals(itemB)||itemA.equals(itemC)||itemB.equals(itemC)){
			       isRepeated=true;
	            }
	            break;
		case(4):if(itemA.equals(itemB)||itemA.equals(itemC)||itemA.equals(itemD)||itemB.equals(itemC)||itemB.equals(itemD)||itemC.equals(itemD)){
			       isRepeated=true;
                }
                break;
		case(5):if(itemA.equals(itemB)||itemA.equals(itemC)||itemA.equals(itemD)||itemA.equals(itemE)||itemB.equals(itemC)||itemB.equals(itemD)||itemB.equals(itemE)||itemC.equals(itemD)||itemC.equals(itemE)||itemD.equals(itemE)){
		           isRepeated=true;
                }
                break;
		case(6):if(itemA.equals(itemB)||itemA.equals(itemC)||itemA.equals(itemD)||itemA.equals(itemE)||itemA.equals(itemF)||itemB.equals(itemC)||itemB.equals(itemD)||itemB.equals(itemE)||itemB.equals(itemF)||itemC.equals(itemD)||itemC.equals(itemE)||itemC.equals(itemF)||itemD.equals(itemE)||itemD.equals(itemF)||itemE.equals(itemF)){
	               isRepeated=true;
                }
                break;
		}
		return isRepeated;
	}

}
