package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.Data;
import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Paper;
import com.questionnare.model.Question;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class CreateTitle
 */
@WebServlet("/CreateTitle")
public class CreateTitle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateTitle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String paperID=request.getParameter("paperID");
		Paper paper=PaperDao.getPaperByPaperID(paperID);
		ArrayList<Question> questions=QuestionDao.getQuestionsByPaperID(paperID);
		String questionList=Generator.generateQuestionList(questions);
		if(paper!=null){
			request.setAttribute("result","success");
			request.setAttribute("paperID",paperID);
			request.setAttribute("title",paper.getTitle());
			request.setAttribute("questionList",questionList);
			request.setAttribute("description",paper.getDescription());
			request.getRequestDispatcher("pages/editNew.jsp").forward(request, response);
			return;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Cookie[] cookies=request.getCookies();
		boolean flag=true;
		for(Cookie cookie:cookies){
			if(cookie.getName().equals("getflag")){
				cookie.setValue("full");
				response.addCookie(cookie);
				flag=false;
				break;
			}
		}
		if(flag){
			Cookie cookie=new Cookie("getflag","full");
			response.addCookie(cookie);
		}
		Data application=new Data();
		String title=request.getParameter("title");
		boolean isRepeat=PaperDao.get(title);
		if(isRepeat){
			Data.result="repeat";
			//request.setAttribute("result","repeat");
			request.getRequestDispatcher("pages/createTitle.jsp").forward(request, response);
			return;
		}
		String paperID=new Long(System.currentTimeMillis()).toString();
		String description=request.getParameter("description");
		String userID=(String)application.getAttribute("userID");
		boolean addResult=PaperDao.add(paperID,title, description, userID);
		if(addResult){
			Data.result="success";
			//request.setAttribute("result","success");
			request.setAttribute("paperID",paperID);
			request.setAttribute("title",title);
			request.setAttribute("description",description);
			request.getRequestDispatcher("pages/editNew.jsp").forward(request, response);
			return;
		}else{
			Data.result="error";
			//request.setAttribute("result","error");
			request.getRequestDispatcher("pages/createTitle.jsp").forward(request, response);
			return;
		}
	}

}
