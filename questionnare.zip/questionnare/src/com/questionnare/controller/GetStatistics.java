package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.AnswerDao;
import com.questionnare.dao.FinishedListDao;
import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Question;
import com.questionnare.util.ChartGenerator;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class GetStatistics
 */
@WebServlet("/GetStatistics")
public class GetStatistics extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetStatistics() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String paperID=(String)request.getParameter("paperID");
		String title=PaperDao.getPaperByPaperID(paperID).getTitle();
		int finishedCount=FinishedListDao.getFinishedCountByPaper(paperID);
		ArrayList<Question> questions=QuestionDao.getQuestionsByPaperID(paperID);
		ArrayList<ArrayList<String>> result=new ArrayList<ArrayList<String>>();
		StringBuilder chartContent=new StringBuilder();
		for(int i=0;i<questions.size();i++){
			Question question=questions.get(i);
			String questionContent=Generator.generateQuestion(question,i+1);
			ArrayList<ArrayList<String>> list=AnswerDao.getListByQuestionID(question.getQuestionID());
			String []head=new String[]{"结果","人数","比例"};
			String resultContent=Generator.generateTable(3, head, list,question.getType());
			ArrayList<String> t=new ArrayList<String>();		
			t.add(question.getQuestionID());
			t.add(question.getType());
			t.add(questionContent);
			t.add(resultContent);
			result.add(t);
			if(!question.getType().equals("3")){
				chartContent.append(ChartGenerator.generateChart(question.getQuestionID(),list));
			}			
		}
		String content=Generator.generateFullStatistics(result);
		request.setAttribute("title", title);
		request.setAttribute("content", content);
		request.setAttribute("chartContent", chartContent);
		request.setAttribute("finishedCount", finishedCount);
		request.getRequestDispatcher("pages/result.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
