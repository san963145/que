package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.Data;
import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Question;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class EditTitle
 */
@WebServlet("/EditTitle")
public class EditTitle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditTitle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Cookie[] cookies=request.getCookies();
		boolean flag=true;
		for(Cookie cookie:cookies){
			if(cookie.getName().equals("getflag")){
				cookie.setValue("full");
				response.addCookie(cookie);
				flag=false;
				break;
			}
		}
		if(flag){
			Cookie cookie=new Cookie("getflag","full");
			response.addCookie(cookie);
		}
		String title=request.getParameter("title");	
		String paperID=request.getParameter("paperID");	
		String description=request.getParameter("description");
		boolean updateResult=PaperDao.update(title, description);
		if(updateResult){
			Data.result="success";
			//request.setAttribute("result","success");
			ArrayList<Question> questions=QuestionDao.getQuestionsByPaperID(paperID);
			String questionList=Generator.generateQuestionList(questions);
			request.setAttribute("paperID",paperID);
			request.setAttribute("title",title);
			request.setAttribute("description",description);
			request.setAttribute("questionList",questionList);
			request.getRequestDispatcher("pages/editNew.jsp?paperID="+paperID).forward(request, response);
			return;
		}else{
			Data.result="error";
			//request.setAttribute("result","error");
			request.getRequestDispatcher("pages/editTitle.jsp?paperID="+paperID).forward(request, response);
			return;
		}
	}

}
