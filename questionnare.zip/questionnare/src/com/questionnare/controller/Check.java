package com.questionnare.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.AdminDao;
import com.questionnare.dao.Data;
import com.questionnare.dao.FinishedListDao;
import com.questionnare.dao.PaperDao;
import com.questionnare.model.Paper;
import com.questionnare.util.ReceiveParser;
import com.questionnare.util.ReplyContent;
import com.questionnare.util.SignUtil;


/**
 * Servlet implementation class Check
 */
@WebServlet("/Check")
public class Check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String signature = request.getParameter("signature");  

		String timestamp = request.getParameter("timestamp");  

        String nonce = request.getParameter("nonce");  
 
        String echostr = request.getParameter("echostr");  
  
        PrintWriter out = response.getWriter();  

        if (SignUtil.checkSignature(signature, timestamp, nonce)) 
        {  
           out.print(echostr);  
        }  
        out.close();  
        out = null;	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");  
        response.setCharacterEncoding("UTF-8");
        Data application=new Data();
        Map<String,String> xmlMap=ReceiveParser.parse(request, response);
        String toUserName=xmlMap.get("toUserName");
        String fromUserName=xmlMap.get("fromUserName");//openID
        String content=xmlMap.get("content");
        String checkUserID=AdminDao.checkUserID(content);       
        String paperID=(String)application.getAttribute("paperID");
        String curOpenID=(String)application.getAttribute("openID");
        String tempOpenID=(String)application.getAttribute("tempOpenID");       
        if(curOpenID!=null){
        	if(curOpenID.equals(fromUserName)){
        		String title="·µ»ØÏµÍ³";
           	    String url=Data.URL+"Login?openID="+fromUserName;
           	    String replyContent="µã»÷½øÈëÎÒµÄÎÊ¾í";
           	    String xml=ReplyContent.generateXML(fromUserName, toUserName, title, replyContent, url);
           	    response.getWriter().write(xml);
           	    return;
        	}        	
        }
        if(tempOpenID!=null){
        	if(tempOpenID.equals(fromUserName)&&checkUserID!=null){
        		String title="ÏµÍ³µÇÂ¼";
           	    String url=Data.URL+"pages/index.jsp?openID="+fromUserName;
           	    String replyContent="µÇÂ¼ÏµÍ³·¢²¼ÎÊ¾í";
           	    String xml=ReplyContent.generateXML(fromUserName, toUserName, title, replyContent, url);
           	    response.getWriter().write(xml);
           	    return;
        	}        	
        }
        if(content.equals("oQB030fIUAh55djI5p1JE4t9l8EI53hs8")){
        	  String title="»¶Ó­½øÈëÎ÷Î÷ÎÊ¾íÍø";
        	  String replyContent="·¢ËÍÈÎÒâÏûÏ¢¿É»ñÈ¡×îÐÂÎÊ¾í";
        	  String xml=ReplyContent.generateXML(fromUserName, toUserName, title, replyContent);
        	  response.getWriter().write(xml);
        	  return;
        }
        if(paperID!=null){ 
        	  Paper paper=PaperDao.getPaperByPaperID(paperID);
        	  boolean isFinished=FinishedListDao.isFinished(paperID, fromUserName);
        	  if(isFinished){
        		  String title=paper.getTitle();
            	  String replyContent="当前终端已提交该问卷,暂无新问卷的发布";
            	  String xml=ReplyContent.generateXML(fromUserName, toUserName, title, replyContent);
            	  response.getWriter().write(xml);
            	  return;
        	  }else{        		        	  
            	  String title=paper.getTitle();
             	  String url=Data.URL+"GetPaper?openID="+fromUserName;
             	  String replyContent="µã»÷Á´½Ó¿ÉÌîÐ´ÎÊ¾í.";
             	  String xml=ReplyContent.generateXML(fromUserName, toUserName, title, replyContent, url);
             	  response.getWriter().write(xml);
             	  return; 
        	  }
        }else if(checkUserID==null){
        	String replyContent="µ±Ç°Î´·¢²¼ÈÎºÎÎÊ¾í,ÇëÌá¹©ÕýÈ·µÄ¹ÜÀíÔ±ÕËºÅ!";
       	    String xml=ReplyContent.generateXML(fromUserName, toUserName, replyContent);
       	    response.getWriter().write(xml);
       	    return;
        }else{
        	String title="ÏµÍ³µÇÂ¼";
       	    String url=Data.URL+"pages/index.jsp?openID="+fromUserName;
       	    String replyContent="µÇÂ¼ÏµÍ³·¢²¼ÎÊ¾í";
       	    String xml=ReplyContent.generateXML(fromUserName, toUserName, title, replyContent, url);
       	    response.getWriter().write(xml);
       	    return;
        }
	}

}
