package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.questionnare.dao.AdminDao;
import com.questionnare.dao.Data;
import com.questionnare.dao.PaperDao;
import com.questionnare.model.Paper;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Data application=new Data();
		String curOpenID=(String)application.getAttribute("openID");
		String openID=request.getParameter("openID");
		if(openID!=null){
			if(curOpenID==null){
				request.getRequestDispatcher("pages/index.jsp?openID="+openID).forward(request, response);
			    return;
			}else if(!curOpenID.equals(openID)){
				request.getRequestDispatcher("pages/index.jsp?openID="+openID).forward(request, response);
			    return;
			}
		}	
		String paperID=(String)application.getAttribute("paperID");
		String userID=(String)application.getAttribute("userID");
		ArrayList<Paper>paperList=PaperDao.getPapersByUserID(userID);
		if(paperID==null)
			paperID="";
		String paperListContent=Generator.generatePaperList(paperID,paperList);
		request.setAttribute("result","success");
		request.setAttribute("paperListContent",paperListContent);
		request.getRequestDispatcher("pages/main.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session=request.getSession();
		Data application=new Data();
		String userID=request.getParameter("userID");
		String password=request.getParameter("password");
		String openID=request.getParameter("openID");
		String loginResult=AdminDao.checkAdminLogin(userID, password);
		if(loginResult==null){
			request.setAttribute("result","error");
			request.getRequestDispatcher("pages/index.jsp").forward(request, response);
			return;
		}else{
			String curUser=(String)application.getAttribute("openID");
			if(curUser!=null){
				if(!curUser.equals(openID)){
					request.setAttribute("result","busy");
					request.getRequestDispatcher("pages/index.jsp").forward(request, response);
					return;
				}				
			}
			application.removeAttribute("userID");
			application.setAttribute("userID", userID);
			if(openID!=null){
				session.removeAttribute("openID");
				application.removeAttribute("openID");
				application.removeAttribute("tempOpenID");
				application.setAttribute("openID", openID);
			}
			ArrayList<Paper>paperList=PaperDao.getPapersByUserID(userID);
			String paperID=(String)application.getAttribute("paperID");
			if(paperID==null)
				paperID="";
			String paperListContent=Generator.generatePaperList(paperID,paperList);
			request.setAttribute("result","success");
			request.setAttribute("paperListContent",paperListContent);
			request.getRequestDispatcher("pages/main.jsp").forward(request, response);
		}
	}
	

}
