package com.questionnare.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.questionnare.dao.AnswerDao;
import com.questionnare.dao.Data;
import com.questionnare.dao.FinishedListDao;
import com.questionnare.dao.PaperDao;
import com.questionnare.dao.QuestionDao;
import com.questionnare.model.Paper;
import com.questionnare.util.Generator;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		Data application=new Data();
		String paperID=(String)request.getParameter("paperID");
		String userID=(String)application.getAttribute("userID");
		AnswerDao.delete(paperID);
		FinishedListDao.delete(paperID);
		QuestionDao.delete(paperID);
		PaperDao.delete(paperID);
		ArrayList<Paper>paperList=PaperDao.getPapersByUserID(userID);
		String curPaperID=(String)application.getAttribute("paperID");
		if(curPaperID==null)
			curPaperID="";
		String paperListContent=Generator.generatePaperList(curPaperID,paperList);		
		request.setAttribute("paperListContent",paperListContent);		
		request.getRequestDispatcher("pages/main.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
